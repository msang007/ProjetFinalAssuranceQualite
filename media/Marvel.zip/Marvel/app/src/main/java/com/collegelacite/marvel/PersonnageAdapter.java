package com.collegelacite.marvel;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class PersonnageAdapter extends BaseAdapter {

    private Context contexte;
    private LayoutInflater inflater;
    private ArrayList<Marvel> sourceDonnees;

    public PersonnageAdapter(Context ctx, ArrayList<Marvel> donnees){
        this.contexte = ctx;
        this.sourceDonnees = donnees;
        this.inflater = (LayoutInflater)this.contexte.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        Collections.shuffle(sourceDonnees);
    }



    @Override
    public int getCount() {
        return sourceDonnees.size();
    }

    @Override
    public Marvel getItem(int i) {
        return sourceDonnees.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View rowView = inflater.inflate(R.layout.list_item_personnage, viewGroup,false);

        Marvel marvel = getItem(i);

        int id = marvel.getDrawableId();
        ImageView iv = rowView.findViewById(R.id.listItemImageView);
        iv.setImageResource(id);

        TextView tvnom = rowView.findViewById(R.id.listItemNomTextView);
        tvnom.setText(marvel.getNom());

        return rowView;
    }
}
