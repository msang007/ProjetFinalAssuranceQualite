package com.collegelacite.marvel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private PersonnageAdapter avengers;    // source de données
    private ArrayList<Marvel> listePersonnageMarvel;
    static int Compteur = 1;
     TextView tvNomEnEnigme;
    // Fonction créant et initialisant l'activité
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        final ArrayList<Marvel> listeMarvel = Marvel.lireFichier(this,false);
        final ArrayList<Marvel> listeMarvelDeux = Marvel.lireFichier(this,true);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // Créer la source de données de l'adaptateur
        avengers = new PersonnageAdapter(this,listeMarvel);

        GridView gv = findViewById(R.id.gridViewId);
        gv.setAdapter(avengers);

        final ConstraintLayout ct = (ConstraintLayout) findViewById(R.id.layoutId);

        tvNomEnEnigme = findViewById(R.id.NomPersonnageATrouverId);
        tvNomEnEnigme.setText(randomAvenger(listeMarvelDeux));

        final String Res = tvNomEnEnigme.getText().toString();



        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                avengers.getItem(i).setDévoilé(true);
                avengers.notifyDataSetChanged();

                    listeMarvel.get(i).setDévoilé(true);

                        if (listeMarvel.get(i).getNom().toString().equals(Res)) {
                            ct.setBackgroundColor(Color.GREEN);
                            Toast.makeText(getApplicationContext(),"Nombre de tentative:"+Compteur,Toast.LENGTH_LONG).show();
                            Compteur = 1;
                        }
                        else {
                            ct.setBackgroundColor(Color.RED);
                            Compteur++;
                        }

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.RestartItem:
                for (int i = 0; i< avengers.getCount(); i++)
                {
                    avengers.getItem(i).setDévoilé(false);
                }
               final ConstraintLayout ct = (ConstraintLayout) findViewById(R.id.layoutId);
                ct.setBackgroundColor(Color.WHITE);
                Compteur = 1;
                //avengers.notifyDataSetChanged();
                tvNomEnEnigme = findViewById(R.id.NomPersonnageATrouverId);
                tvNomEnEnigme.setText(randomAvenger(Marvel.lireFichier(this,true)));
                avengers.notifyDataSetChanged();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public  String randomAvenger(ArrayList<Marvel> m) {
        Random random = new Random();
        int rand_int = random.nextInt(m.size());
        return m.get(rand_int).getNom();
    }




}
