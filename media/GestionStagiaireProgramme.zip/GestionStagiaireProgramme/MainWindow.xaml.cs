﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using Newtonsoft.Json;



namespace GestionDesStagiaires
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    //references: 
    // https://stackoverflow.com/questions/39924376/how-to-bind-json-to-listview-control
    // https://www.wpf-tutorial.com/listview-control/listview-with-gridview/
    // https://stackoverflow.com/questions/1268552/how-do-i-get-a-textbox-to-only-accept-numeric-input-in-wpf
    // https://stackoverflow.com/questions/273141/regex-for-numbers-only
    // https://stackoverflow.com/questions/9289451/regular-expression-for-alphabets-with-spaces/9289472 // Valider string compose de lettre et espace seulement
    // https://stackoverflow.com/questions/3028642/regular-expression-for-letters-numbers-and // Valider string compose de lettre et nombre
    //https://www.it-swarm-fr.com/fr/c%23/comment-lier-une-liste-une-combobox/957824649/ // affecter une liste a un comboBox
    //
    //

    public partial class MainWindow : Window
    {

        //Déclaration des variables
        private string numeroProgramme; //Pour garder la valeur du numero du programme saisie
        private string nomProgramme; //Pour garder la valeur du nom du programme saisie
        private int dureeProgramme; //Pour garder la valeur du numero du programme saisie
        private bool indicateurNumeroProgramme=false; //Pour indiquer que le numero du programme est valide.
        private bool indicateurNomProgramme = false; //Pour indiquer que le nom du programme est valide.
        private bool indicateurDureeProgramme = false; //Pour indiquer que la duree du programme est valide.
        public ListeProgramme listeProgramme = new ListeProgramme();
        

        // la base de donnees. pour l'instant c un string mais on  peut le transfromer en fichier
        static string jsonString = "[   { \"Num\":\"1\",\"Nom\":\"Hadroug\",\"Prenom\":\"Dalyne\",\"Date_naissance\":\"1999-11-11  \",\"Sexe\":\"Homme\",\"Programme\":\"1\" } " +
                 " ,"  + " {\"Num\":\"2\",\"Nom\":\"Nom1\",\"Prenom\":\"Prenom1\",\"Date_naissance\":\"2001-09-11\",\"Sexe\":\"Other\",\"Programme\":\"2\"}  " +
                 " ," + " {\"Num\":\"3\",\"Nom\":\"Nom2\",\"Prenom\":\"Prenom2\",\"Date_naissance\":\"2001-09-11\",\"Sexe\":\"Homme\",\"Programme\":\"4\"} " +
                 " ," + " {\"Num\":\"4\",\"Nom\":\"Nom3\",\"Prenom\":\"Prenom3\",\"Date_naissance\":\"2001-09-11\",\"Sexe\":\"Femme\",\"Programme\":\"1\"} " +
                 " ," + " {\"Num\":\"5\",\"Nom\":\"Nom4\",\"Prenom\":\"Prenom4\",\"Date_naissance\":\"2001-09-11\",\"Sexe\":\"Homme\",\"Programme\":\"1\"} " +
                 " ," + " {\"Num\":\"6\",\"Nom\":\"Nom5\",\"Prenom\":\"Prenom5\",\"Date_naissance\":\"2001-09-11\",\"Sexe\":\"Femme\",\"Programme\":\"2\"}]";

        List<Stagiaire> listStagiaire = Consulter.ListConsulter(jsonString);

        public MainWindow()
        {

            InitializeComponent();

            
            // lvStagiaires est l'id de la listview graphique
            // Consulter.ListConsulter(jsonString) est une methode du fichier Consulter.cs
            lvStagiaires.ItemsSource = listStagiaire;


           




        }
        


        private void Ajouter_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Supprimer_Click(object sender, RoutedEventArgs e)
        {

        }

        //evenement du button rechercher 
        private void btnRechercher_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int num = Int32.Parse(txtboxProgramme.Text); //on recupere ce qui a dans le textbox et on le transfrom en int
                txtboxProgramme.Text = ""; // on efface le contenu du textbox
                if (Consulter.ButtonConsulter(num, listStagiaire).Count() == 0)  // si il aucun stagiaire qui a fait le programme numero "num"
                {
                    string text = "Aucun Resultat Trouvé";
                    System.Windows.MessageBox.Show(text); //pop up
                }
                else //si il ya des stagiaires qui ont fait le programme en question
                {
                    lvStagiaires.ItemsSource = Consulter.ButtonConsulter(num, listStagiaire); //on les affiche
                }
            }


            catch { }
           
            
            

        }

        /*private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            lvStagiaires.ItemsSource = listStagiaire;
            txtboxProgramme.Text = "";
            
        }*/

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void btnEffacer_Click(object sender, RoutedEventArgs e)
        {
            // Effacer les textBox
            txt_Numero.Text = " ";
            txt_Prenom.Text = " ";
            txt_Nom.Text = " ";
            // Effacer la date et le reset
            date_Picker.Text = string.Empty;
            // Effacer le champs de la liste de mes programmes et le reinitialiser
            cbox_Liste_Programme.Items.Clear();
            // Effacer le champs de mes RadioButtons
            radioBtnMasculin.IsChecked = false;
            radioBtnFeminin.IsChecked = false;
            radioBtnAutre.IsChecked = false;

            System.Windows.MessageBox.Show("Clear Successfully");
        }

        /// <summary>
        /// Bouton pour ajouter programme, elle valide le numero, le nom et la duree du programme
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAjouterPrg_Click(object sender, RoutedEventArgs e)
        {
          //do //J'ai tenté de faire la validation avec un do while mais mon programme a gelé donc je suis alle avec un if tel que écrit a la ligne 214
          //{
                try
                {
                    numeroProgramme = txtNumeroProg.Text; //Recuperation de la chaine saisie dans le textbox pour le numero du programme
                    if (numeroProgramme.Length == 0) //Valider si le numero du programme est vide. J'ai créée cette exception car il en avait pas sur visual studio.
                    {
                    indicateurNumeroProgramme = false; //Affecter l'indicateur a false si le nombre n'est pas valide
                    throw new Exception("Le champ du numero du programme est vide.");
                    }
                    if (!(Regex.IsMatch(numeroProgramme, @"^[a-zA-Z0-9]+$")))
                    {
                        indicateurNumeroProgramme = false;
                        lblValidNumero.Content = "MAUVAIS NUMERO DE PROG.";
                    }
                    else
                    {
                        indicateurNumeroProgramme = true;
                        lblValidNumero.Content = "";
                    }
                }
                catch (Exception)
                {

                    lblValidNumero.Content = "Veuillez saisir le numero du programme";
                }

                try
                {
                    nomProgramme = txtNomProg.Text; //Recuperation de la chaine saisie dans le textbox pour le nom du programme
                    if (nomProgramme.Length == 0) //Valider si le nom du programme est vide. J'ai créée cette exception car il en avait pas sur visual studio.
                    {
                        indicateurNomProgramme = false; //Affecter l'indicateur a false si le nom n'est pas valide
                        throw new Exception("Le champ du nom du programme est vide.");
                    }
                    if (!(Regex.IsMatch(nomProgramme, @"[\p{L} ]+$")))
                    {
                        lblValidNom.Content = "MAUVAIS NOM DE PROG.";
                        indicateurNomProgramme = false;
                    }
                    else
                    {
                        indicateurNomProgramme = true;
                        lblValidNom.Content = "";
                    }
                }
                catch (Exception)
                {
                    lblValidNom.Content = "Veuillez saisir le nom du programme";
                }

                try
                {
                    dureeProgramme = int.Parse(txtDureeProg.Text); //Recuperation de duree saisie dans le textbox.
                    if (dureeProgramme > 48 || dureeProgramme < 0) //valider si le nombre est entre 1 et 48.
                    {
                        indicateurDureeProgramme = false;//Affecter l'indicateur a false si la duree n'est pas valide
                        lblValidDuree.Content = "MAUVAIS DUREE DE PROG."; //Affichage du message d'erreur pour demander utilisateur de re-saisir.
                    }
                    else
                    {
                        indicateurDureeProgramme = true;
                        lblValidDuree.Content = ""; //Mettre la variable dans une liste.
                    }
                }
                catch (FormatException) //Exception pour valider si le textbox est vide.
                {
                    lblValidDuree.Content = "Veuillez entre un nombre entre 1 et 48";
                }

          //}
          //while (indicateurNumeroProgramme || indicateurNomProgramme || indicateurDureeProgramme);

            //Sortir du deroulement du programme si un des indicateurs est false et executer le bloc de code ci-dessous seulement quand les 3 incateurs sont a true;
            if (!indicateurNumeroProgramme || !indicateurNomProgramme || !indicateurDureeProgramme)
            {
                return;   
            }

            //Creation d'un programme
            Programme nouveauProgramme = new Programme(numeroProgramme, nomProgramme, dureeProgramme);
            //Ajout du programme a la liste des programmes
            listeProgramme.Ajouter(nouveauProgramme);
            //Affichage d'un message pour confirmer que le programme a été ajouté.
            lblValidAjouter.Content = "Le programme : " + numeroProgramme + " - " + nomProgramme + " d'une durée de " + dureeProgramme + " mois a été ajouté avec succès.";

            //Réinitialisation des textbox quand un programme a été ajouté avec succèes
            txtNumeroProg.Text = "";
            txtNomProg.Text = "";
            txtDureeProg.Clear();


            //lblTest.Content = listeProgramme.AfficherListe(); //Affichage de la liste des programme pour tester
        }

        /// <summary>
        /// Methode pour supprimer un programme de la liste des programmes a partir d'un numero
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSupprimerPrg_Click(object sender, RoutedEventArgs e)
        { 
            //Validation du numero du programme pour voir 
            try
            {
                numeroProgramme = txtNumeroProg.Text; //Recuperation de la chaine saisie dans le textbox pour le numero du programme

                listeProgramme.ChercherNumeroProgramme(numeroProgramme);

                /*
                if (listeProgramme.ChercherNumeroProgramme(numeroProgramme))
                {
                    lblTest.Content = "le programme est trouve";
                }
                else
                {
                    indicateurNumeroProgramme = true;
                    lblValidNumero.Content = "";
                }

                
                if (numeroProgramme.Length == 0) //Valider si le numero du programme est vide. J'ai créée cette exception car il en avait pas sur visual studio.
                {
                    indicateurNumeroProgramme = false; //Affecter l'indicateur a false si le nombre n'est pas valide
                    throw new Exception("Le champ du numero du programme est vide.");
                }
                if (!(Regex.IsMatch(numeroProgramme, @"^[a-zA-Z0-9]+$")))
                {
                    indicateurNumeroProgramme = false;
                    lblValidNumero.Content = "MAUVAIS NUMERO DE PROG.";
                }
                else
                {
                    indicateurNumeroProgramme = true;
                    lblValidNumero.Content = "";
                }
                */
            }
            catch (Exception)
            {

                lblValidNumero.Content = "Veuillez saisir le numero du programme";
            }

        }

        /// <summary>
        /// Fonction pour effacer le contenu dans les composants de l'onglet programme sur le clique
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEffacerPrg_Click(object sender, RoutedEventArgs e)
        {
            txtNumeroProg.Text = "";
            txtNomProg.Text = "";
            txtDureeProg.Clear();
            lblValidNumero.Content = "";
            lblValidNom.Content = "";
            lblValidDuree.Content = "";
            lblValidAjouter.Content = "";
        }

        private void btnAjouterstg_Click(object sender, RoutedEventArgs e)
        {
            int num = Int32.Parse(txt_Numero.Text);
            string nom = txt_Nom.Text;
            string prenom = txt_Prenom.Text;
            string date = date_Picker.Text;
            string sexe;

            if (radioBtnMasculin.IsChecked == true) { sexe = radioBtnMasculin.Content.ToString(); }
            else if (radioBtnFeminin.IsChecked == true) { sexe = radioBtnFeminin.Content.ToString(); }
            else { sexe = radioBtnAutre.Content.ToString(); }

            string strprogram = cbox_Liste_Programme.Text;
            char numprogram = strprogram[0];
            int programme = (int)Char.GetNumericValue(numprogram);

            Stagiaire S = new Stagiaire(num, nom, prenom, date, sexe, programme);
            listStagiaire.Add(S);
            lvStagiaires.ItemsSource = listStagiaire;

            MessageBox.Show("Stagiaire ajouté avec succes");

           


        }

        private void btnresetlist_Click(object sender, RoutedEventArgs e)
        {
            List<Stagiaire> listStagiairex = new List<Stagiaire>();
            foreach (var item in listStagiaire)
            {
                 listStagiairex.Add(item); 
            }
            lvStagiaires.ItemsSource = listStagiairex;
            txtboxProgramme.Text = "";

        }

        private void btnSupprimerstg_Click(object sender, RoutedEventArgs e)
        {
            int num = Int32.Parse(txt_Numero.Text);
            List<Stagiaire> listStagiairex = new List<Stagiaire>();
            foreach (var item in listStagiaire)
            {
                if (item.Num != num) listStagiairex.Add(item);
            }
            

            lvStagiaires.ItemsSource = listStagiairex;
            MessageBox.Show("Stagiaire supprimé avec succes");
            listStagiaire = listStagiairex;

        }

       







        
        
            





    }

   
}
