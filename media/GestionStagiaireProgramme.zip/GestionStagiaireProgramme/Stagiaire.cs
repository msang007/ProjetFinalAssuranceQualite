﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionDesStagiaires
{
    class Stagiaire
    {

        public int Num { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Date_naissance { get; set; }
        public string Sexe { get; set; }
        public int Programme { get; set; }

        //public int? Age = DateTime.Today.Year - Date_naissance.Year; { get; set; }
        public Stagiaire(int Num, string Nom, string Prenom, string Date_naissance, string Sexe, int Programme)
        {
            this.Num = Num;
            this.Nom = Nom;
            this.Prenom = Prenom;
            this.Date_naissance = Date_naissance;
            this.Sexe = Sexe;
            this.Programme = Programme;
        }
        public Stagiaire() { }

        


        
    }
}
