﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionDesStagiaires
{
    /// <summary>
    /// Classe ListeProgramme pour lister les programmes.
    /// </summary>
    public class ListeProgramme
    {
        /// <summary>
        /// Definition des proprietes. 
        /// </summary>
        public List<Programme> ListeProg { get; set; }

        /// <summary>
        /// Constructeur pour creer une liste de programme.
        /// </summary>
        public ListeProgramme()
        {
            this.ListeProg = new List<Programme>();
        }

        /// <summary>
        /// Fonction pour ajouter un programme a la liste.
        /// </summary>
        /// <param name="p"></param>
        public void Ajouter(Programme p)
        {
            ListeProg.Add(p);
        }

        /// <summary>
        /// Fonction pour supprimer un programme
        /// </summary>
        /// <param name="p"></param>
        public void Supprimer(Programme p)
        {
            ListeProg.Remove(p);
        }

        /// <summary>
        /// Methode pour chercher un nom du programme dans la liste.
        /// </summary>
        /// <param name="nomProgramme"></param>
        /// <returns></returns>
        public Programme ChercherNomProgramme(string nomProgramme)
        {
            foreach (Programme p in this.ListeProg)
            {
                if(p.NomProgramme == nomProgramme)
                {
                    return p;
                }
            }
            return null;
        }

        /// <summary>
        /// Methode pour chercher un programme a l'aide de son numero
        /// </summary>
        /// <param name="nomProgramme"></param>
        /// <returns></returns>
        public Programme ChercherNumeroProgramme(string numeroProgramme)
        {
            foreach (Programme p in this.ListeProg)
            {
                if (p.NumeroProgramme == numeroProgramme)
                {
                    return p;
                }
            }
            return null;
        }

        /// <summary>
        /// Chercher un programme a l'aide son nom, son numero et sa duree.
        /// </summary>
        /// <param name="nomProgramme"></param>
        /// <param name="numeroProgramme"></param>
        /// <param name="dureeProgramme"></param>
        /// <returns></returns>
        public Programme chercher(string nomProgramme, string numeroProgramme, int dureeProgramme)
        {
            foreach (Programme p in this.ListeProg)
            {
                if (p.NomProgramme == nomProgramme && p.NumeroProgramme == numeroProgramme && p.DureeProgramme == dureeProgramme)
                {
                    return p;
                }
            }
            return null;
        }

        /// <summary>
        /// Afficher la liste des programmes
        /// </summary>
        /// <returns></returns>
        public string AfficherListe()
        {
            string tableau = "";
            foreach (Programme p in this.ListeProg)
            {
                tableau += p.ToString();
            }
            return tableau;
        }

        /// <summary>
        /// Redefinition de la fonction ToString()
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.GetType().Name + " : " +
                //"\nNombre d'etudiant : " + this.listeProg.Count +
                "\nListe des programmes : " + this.ListeProg.ToString();
        }

        /// <summary>
        /// Redéfinition GetHashCode()
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }





    }
}
