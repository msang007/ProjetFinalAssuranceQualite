﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionDesStagiaires
{
    /// <summary>
    /// Classe programme.
    /// </summary>
    public class Programme
    {
        /// <summary>
        /// Definition des proprietes.
        /// </summary>
        public string NumeroProgramme { get; set; }
        public string NomProgramme { get; set; }
        public int DureeProgramme { get; set; }

        /// <summary>
        /// Constructeur d'un programme
        /// </summary>
        /// <param name="numeroProgramme"></param>
        /// <param name="nomProgramme"></param>
        /// <param name="dureeProgramme"></param>
        public Programme(string numeroProgramme, string nomProgramme, int dureeProgramme)
        {
            this.NumeroProgramme = numeroProgramme;
            this.NomProgramme = nomProgramme;
            this.DureeProgramme = dureeProgramme;
        }

        /// <summary>
        /// Redéfinition de la méthode ToString()
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.GetType().Name + " : " + "\n" +
                    "Numero du programme: " + this.NumeroProgramme + "\n" +
                    "Nom du programme : " + this.NomProgramme + "\n" +
                    "Duree : " + this.DureeProgramme + "\n";
        }

        /// <summary>
        /// //Redéfinition GetHashCode()
        /// </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

    }
}
