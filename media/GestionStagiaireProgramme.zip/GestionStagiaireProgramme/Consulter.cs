﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace GestionDesStagiaires
{
    class Consulter
    {
            //methode qui transoforme un Json en liste
            // elle retourne une liste de stagiaires
        public static List<Stagiaire> ListConsulter(string jsonString) 
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            List<Stagiaire> listStagiaire = (List<Stagiaire>)ser.Deserialize(jsonString, typeof(List<Stagiaire>));


            return listStagiaire; 
        }

        //mothode qui retourne une liste ou tous les programmes de la liste est = a num
        public static List<Stagiaire> ButtonConsulter(int num, List<Stagiaire> listStagiaire)
        {

            List<Stagiaire> listStagiaire2 = new List<Stagiaire>();
            listStagiaire2.Clear();

             foreach (var item in listStagiaire)
            {
                if (item.Programme == num) { listStagiaire2.Add(item); }
            } 


            return listStagiaire2;
        }
    }
}
